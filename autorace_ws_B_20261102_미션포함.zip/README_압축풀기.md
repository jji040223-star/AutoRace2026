# 압축 풀기 (미션 포함판)

홈 폴더에서 풀면 두 폴더가 원래 자리에 들어간다:

    cd ~
    unzip ~/Desktop/autorace_ws_B_20261102_미션포함.zip

- ~/autorace_ws                         : 워크스페이스 소스 (커밋 2094c4d). 설치·빌드·실행은 ~/autorace_ws/INSTALL_다른PC.md
- ~/LimoIsaacSIM/autorace_2026/data/mission : 미션 시설물 USD (정차 LIMO·표지판·신호등·라바콘·주차 LIMO·광고 화면)
                                          params_sim.yaml missions.usd = ~/LimoIsaacSIM/autorace_2026/data/mission/autorace_2026_missions.usda
- ~/LimoIsaacSIM/autorace_2026/config/missions.yaml : 시설물 배치 값 (참고용 — USD 를 다시 만드는 도구는 안 들어 있음)
- ~/LimoIsaacSIM/USD/WegoLimo/Limo/limo_diff_thin.usd, RPLidar_S2e.usd : 정차 LIMO 모형이 참조하는 WeGo LIMO 모델 (WeGo 배포물)

시뮬 로그에 "미션 USD 없음 → 시설물 없이 진행" 이 나오면 위 경로가 틀린 것. 홈이 아닌 곳에 풀었다면 params_sim.yaml 의 missions.usd 를 고친다.
